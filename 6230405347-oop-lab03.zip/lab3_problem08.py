positive_integers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
str_integers = [str(number) for number in positive_integers]
print(", ".join(str_integers))
