fruits = ["Grapefruit", "Longan", "Orange", "Apple", "Cherry"]
for i, j in enumerate(fruits, 1):
        print(f"{i}. {j}")