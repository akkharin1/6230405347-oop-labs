while True:
    integers = int(input("Enter an integers:"))
    if integers % 2 == 0:
        print(integers)
    elif integers == 99:
        break