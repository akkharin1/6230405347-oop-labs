i = 1
total = 0
while total <= 200:
        total += (i ** 2)
        i += 1
print("The final total is", total)




